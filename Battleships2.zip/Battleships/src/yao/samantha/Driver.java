package yao.samantha;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class Driver {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		Board player = new Board(10, 10);

		player.displayBoard();

		System.out.println("Time to place your monkeys :D");
		System.out.println("Enter the x and y coordinates");
		System.out.println("e.g. for A1, input \"0,0\"");
		int carrierX = getInt(in, "X-coordinate of Carrier (size:5):");
		int carrierY = getInt(in, "Y-coordinate of Carrier (size:5):");
		String carrierOrientation = getString(in, "Horizontal or Vertical (h/v):");

		int battleshipX = getInt(in, "X-coordinate of Battleship (size:4):");
		int battleshipY = getInt(in, "Y-coordinate of Battleship (size:4):");
		String battleshipOrientation = getString(in, "Horizontal or Vertical (h/v):");

		int cruiserX = getInt(in, "X-coordinate of Cruiser (size:3):");
		int cruiserY = getInt(in, "Y-coordinate of Cruiser (size:3):");
		String cruiserOrientation = getString(in, "Horizontal or Vertical (h/v):");

		System.out.println("X-coordinate of Submarine (size:3):");
		int submarineX = in.nextInt();
		System.out.println("Y-coordinate of Submarine (size:3):");
		int submarineY = in.nextInt();
		String submarineOrientation = getString(in, "Horizontal or Vertical (h/v):");

		System.out.println("X-coordinate of Destroyer (size:2):");
		int destroyerX = in.nextInt();
		System.out.println("Y-coordinate of Destroyer (size:2):");
		int destroyerY = in.nextInt();
		String destroyerOrientation = getString(in, "Horizontal or Vertical (h/v):");

	}

	public static String getString(Scanner input, String prompt) {
		boolean valid = false;
		String x = "hello there";
		while (!valid) {
			System.out.println(prompt);
			if (input.hasNextLine()) {
				x = input.nextLine();
				valid = true;
			} else {
				input.nextLine();
				System.out.println("Not a valid string. Try again.");
			}
		}
		return x;

	}

	public static int getInt(Scanner input, String prompt) {
		boolean valid = false;
		int x = 66;
		while (!valid) {
			System.out.println(prompt);
			if (input.hasNextInt()) {
				x = input.nextInt();
				valid = true;
			} else {
				input.nextLine();
				System.out.println("Not a valid integer. Try again.");
			}
		}
		return x;
	}
}
