package yao.samantha;

public enum CellState {
	EMPTYCLOSE, EMPTYOPEN, SHIPSAFE, SHIPBOMBED
}
