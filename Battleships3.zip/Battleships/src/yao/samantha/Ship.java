package yao.samantha;

public class Ship {
	private int x;
	private int y;
	private String orientation;
	private int size;

	public Ship(int x, int y, String orientation, int size) {
		this.x = x;
		this.y = y;
		this.orientation = orientation;
		this.size = size;
	}

	public int[][] getCoverage() {
		int[][] coverage = new int[size][2];
		if (orientation == "h") {
			int tempx = x;
			for (int i = 0; i < size; i++) {
				coverage[i][0] = tempx;
				coverage[i][1] = y;
				tempx++;
			}
		} else if (orientation == "v") {
			int tempy = y;
			for (int i = 0; i < size; i++) {
				coverage[i][0] = x;
				coverage[i][1] = tempy;
				tempy++;
			}
		}
		return coverage;
	}

}
