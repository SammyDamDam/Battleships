package yao.samantha;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class Driver {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		Board player = new Board(10, 10);

		player.displayBoard();

		System.out.println("Time to place your monkeys :D");
		System.out.println("Enter the x and y coordinates, and the orientation");
		System.out.println("e.g. for A1 vertical ship, input \"0,0,v\"");
		
		int x = getInt(in, "X-coordinate of Carrier (size:5):");
		int y = getInt(in, "Y-coordinate of Carrier (size:5):");
		in.nextLine();
		String o = getString(in, "Horizontal or Vertical (h/v):");
		Ship carrier = new Ship (x,y,o,5);
		carrier.displayCoverage();
		x = getInt(in, "X-coordinate of Battleship (size:4):");
		y = getInt(in, "Y-coordinate of Battleship (size:4):");
		in.nextLine();
		o = getString(in, "Horizontal or Vertical (h/v):");
		Ship battleship = new Ship (x,y,o,4);
		
		x = getInt(in, "X-coordinate of Cruiser (size:3):");
		y = getInt(in, "Y-coordinate of Cruiser (size:3):");
		in.nextLine();
		o = getString(in, "Horizontal or Vertical (h/v):");
		Ship cruiser = new Ship (x,y,o,3);
		
		x = getInt(in, "X-coordinate of Submarine (size:3):");
		y = getInt(in, "Y-coordinate of Submarine (size:3):");
		in.nextLine();
		o = getString(in, "Horizontal or Vertical (h/v):");
		Ship submarine = new Ship (x,y,o,3);

		x = getInt(in, "X-coordinate of Destroyer (size:2):");
		y = getInt(in, "Y-coordinate of Destroyer (size:2):");
		in.nextLine();
		o = getString(in, "Horizontal or Vertical (h/v):");
		Ship destroyer = new Ship (x,y,o,2);
		
		

	}

	public static String getString(Scanner input, String prompt) {
		boolean valid = false;
		String x = "hello there";
		while (!valid) {
			System.out.println(prompt);
			if (input.hasNextLine()) {
				x = input.nextLine();
				valid = true;
			} else {
				input.nextLine();
				System.out.println("Not a valid string. Try again.");
			}
		}
		return x;

	}

	public static int getInt(Scanner input, String prompt) {
		boolean valid = false;
		int x = 66;
		while (!valid) {
			System.out.println(prompt);
			if (input.hasNextInt()) {
				x = input.nextInt();
				valid = true;
			} else {
				input.nextLine();
				System.out.println("Not a valid integer. Try again.");
			}
		}
		return x;
	}
}
