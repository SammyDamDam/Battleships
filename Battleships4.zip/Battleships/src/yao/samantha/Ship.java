package yao.samantha;

public class Ship {
	private int x;
	private int y;
	private String orientation;
	private int size;

	public Ship(int x, int y, String orientation, int size) {
		this.x = x;
		this.y = y;
		this.orientation = orientation;
		this.size = size;
	}

	public int[][] getCoverage() {
		System.out.println(orientation);
		int[][] coverage = new int[size][2];
		if (orientation == "h") {
			for (int i = 0; i < size; i++) {
				coverage[i][0] = x + i;
				coverage[i][1] = y;
				System.out.println("hellothere");
			}
		} else if (orientation == "v") {
			for (int i = 0; i < size; i++) {
				coverage[i][0] = x;
				coverage[i][1] = y + i;
			}
		}
		coverage[0][0] = 12;
		return coverage;
	}

	public void displayCoverage() {
		for (int i = 0; i < getCoverage().length; i++) {
			System.out.println(Integer.toString(getCoverage()[i][0]));
			System.out.println(Integer.toString(getCoverage()[i][1]));
		}
	}

}
