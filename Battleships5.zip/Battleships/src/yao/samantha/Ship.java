package yao.samantha;

public class Ship {
	private int x;
	private int y;
	private Orientation orientation;
	private int size;

	public Ship(int x, int y, String orientation, int size) {
		this.x = x;
		this.y = y;
		if (orientation == "h") {
			this.orientation = Orientation.HORIZONTAL;
		} else if (orientation == "v") {
			this.orientation = Orientation.VERTICAL;
		}
		this.size = size;
	}

	public Orientation getOrientation() {
		return orientation;
	}

	public int[][] getHorizontalCoverage() {
		int[][] coverage = new int[size][2];
		for (int i = 0; i < size; i++) {
			coverage[i][0] = x + i;
			coverage[i][1] = y;
		}
		return coverage;
	}
/**
 * Displays the list of coordinates which a horizontal Ship covers
 * "hellothere" is just for testing
 */
	public void displayHorizontalCoverage() {
		for (int i = 0; i < getHorizontalCoverage().length; i++) {
			System.out.println(Integer.toString(getHorizontalCoverage()[i][0]));
			System.out.println(Integer.toString(getHorizontalCoverage()[i][1]));
		}
		System.out.println("hellothere");
	}

	public int[][] getVerticalCoverage() {
		int[][] coverage = new int[size][2];
		for (int i = 0; i < size; i++) {
			coverage[i][0] = x;
			coverage[i][1] = y + 1;
		}
		return coverage;
	}

	public void displayVerticalCoverage() {
		for (int i = 0; i < getHorizontalCoverage().length; i++) {
			System.out.println(Integer.toString(getVerticalCoverage()[i][0]));
			System.out.println(Integer.toString(getVerticalCoverage()[i][1]));
		}
		System.out.println("hellothere");
	}

}
