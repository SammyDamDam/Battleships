package yao.samantha;

public enum Orientation {
	HORIZONTAL, VERTICAL
}
