package yao.samantha;

public class Board {
	private Cell[][] board;
	private int rows;
	private int cols;

	public Board(int rows, int cols) {
		board = new Cell[rows][cols];
		this.rows = rows;
		this.cols = cols;
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				board[i][j] = new Cell(CellState.EMPTYCLOSE);
			}
		}
	}

	public Cell[][] getBoard() {
		return board;
	}

	public boolean placeShip(Ship ship) {
		boolean valid = true;
		if (board[ship.getX()][ship.getY()].getState() == CellState.EMPTYCLOSE) {
			board[ship.getX()][ship.getY()].setState(CellState.SHIPSAFE);
		} else {
			System.out.println("Invalid position.");
			valid = false;
		}
		return valid;
	}

	public void uncover(int x, int y) {
		if (board[x][y].getState() == CellState.EMPTYCLOSE) {
			board[x][y].setState(CellState.EMPTYOPEN);
			System.out.println("No ship here.");
		} else if (board[x][y].getState() == CellState.SHIPSAFE) {
			board[x][y].setState(CellState.SHIPBOMBED);
			System.out.println("Congrats! You bombed a ship.");
		} else {
			System.out.println("Sorry! This position has been uncovered already.");
		}
	}

	public boolean gameOver() {
		boolean gameOver = true;
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				if (board[i][j].getState() == CellState.SHIPSAFE) {
					gameOver = false;
					break;
				}
			}
		}
		return gameOver;
	}

	public int getRows() {
		return rows;
	}

	public int getCols() {
		return cols;
	}

	public void displayPlayerBoard() {
		System.out.println("YOUR BOARD");
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				System.out.printf("%s ", board[i][j]);
			}
			System.out.println();
		}
	}
	public void displayAIBoard() {
		System.out.println("OPPONENT BOARD");
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				System.out.printf("%s ", board[i][j]);
			}
			System.out.println();
		}
	}
	
}
