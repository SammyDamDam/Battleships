package yao.samantha;

public class Cell {
	private CellState cellstate;

	public Cell(CellState cs) {
		cellstate = cs;
	}

	public void setState(CellState cs) {
		cellstate = cs;
	}

	public CellState getState() {
		return cellstate;
	}

	public String toString() {
		switch (cellstate) {
		case EMPTYCLOSE:
			return "0";
		case EMPTYOPEN:
			return "2";
		case SHIPSAFE:
			return "1";
		case SHIPBOMBED:
			return "3";
		default:
			return "-";
		}
	}
}
