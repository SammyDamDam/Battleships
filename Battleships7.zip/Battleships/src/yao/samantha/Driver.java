package yao.samantha;

import java.util.Scanner;
import java.util.Random;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class Driver extends Application {

	public static void main(String[] args) {
		launch(args);
		Scanner in = new Scanner(System.in);
		Board player = new Board(10, 10);
		Random rn = new Random();
		Board ai = new Board(10, 10);
		setaiboard(ai, rn);

		System.out.println("Welcome to Battleships!");
		player.displayPlayerBoard();

		System.out.println("Time to place your ships :D");
		System.out.println("Enter the x and y coordinates, and the orientation");
		System.out.println("e.g. for A1 vertical ship, input \"0,0,v\"");

		boolean validPosition = false;
		while (!validPosition) {
			int x = getInt(in, "X-coordinate of Carrier (size:5):");
			int y = getInt(in, "Y-coordinate of Carrier (size:5):");
			in.nextLine();
			String o = getString(in, "Horizontal or Vertical (h/v):");
			Ship carrier = new Ship(x, y, o, 5);
			validPosition = player.placeShip(carrier);

		}
		validPosition = false;
		while (!validPosition) {
			int x = getInt(in, "X-coordinate of Battleship (size:4):");
			int y = getInt(in, "Y-coordinate of Battleship (size:4):");
			in.nextLine();
			String o = getString(in, "Horizontal or Vertical (h/v):");
			Ship battleship = new Ship(x, y, o, 4);
			validPosition = player.placeShip(battleship);
		}
		validPosition = false;
		while (!validPosition) {
			int x = getInt(in, "X-coordinate of Cruiser (size:3):");
			int y = getInt(in, "Y-coordinate of Cruiser (size:3):");
			in.nextLine();
			String o = getString(in, "Horizontal or Vertical (h/v):");
			Ship cruiser = new Ship(x, y, o, 3);
			validPosition = player.placeShip(cruiser);
		}

		validPosition = false;
		while (!validPosition) {
			int x = getInt(in, "X-coordinate of Submarine (size:3):");
			int y = getInt(in, "Y-coordinate of Submarine (size:3):");
			in.nextLine();
			String o = getString(in, "Horizontal or Vertical (h/v):");
			Ship submarine = new Ship(x, y, o, 3);
			validPosition = player.placeShip(submarine);

		}

		validPosition = false;
		while (!validPosition) {
			int x = getInt(in, "X-coordinate of Destroyer (size:2):");
			int y = getInt(in, "Y-coordinate of Destroyer (size:2):");
			in.nextLine();
			String o = getString(in, "Horizontal or Vertical (h/v):");
			Ship destroyer = new Ship(x, y, o, 2);
			validPosition = player.placeShip(destroyer);
		}

		while (!player.gameOver() && !ai.gameOver()) {
			player.displayPlayerBoard();
			emergency(rn, player);
			ai.displayAIBoard();
			System.out.println("Your Turn");
			playerturn(in, ai);

		}
		System.out.println(winner(ai));

	}

	public void start(Stage mainStage) {
		mainStage.setWidth(400);
		mainStage.setHeight(400);
		mainStage.setTitle("Battleships");

		mainStage.show();
	}

	public static String winner(Board ai) {
		int playerscore = 0;
		for (int x = 0; x < ai.getRows(); x++) {
			for (int y = 0; y < ai.getCols(); y++) {
				if (ai.getBoard()[x][y].getState() == CellState.SHIPBOMBED) {
					playerscore++;
				}
			}
		}

		if (playerscore == 5) {
			return "You win! :3";
		} else {
			return "You lost to the braindead AI. :3";
		}
	}

	public static void playerturn(Scanner scan, Board aiboard) {
		int x = getInt(scan, "Enter x-coordinate of the place you want to terrorize.");
		int y = getInt(scan, "Enter y-coordinate of the place you want to terorize.");
		aiboard.uncover(x, y);

	}

	public static void emergency(Random rand, Board bored) {
		boolean jsartistic = true;
		int x = rand.nextInt(bored.getRows());
		int y = rand.nextInt(bored.getCols());
		System.out.println("OPPONENT TURN");
		while (jsartistic) {
			x = rand.nextInt(bored.getRows());
			y = rand.nextInt(bored.getCols());
			if (bored.getBoard()[x][y].getState() == CellState.SHIPSAFE
					|| bored.getBoard()[x][y].getState() == CellState.EMPTYCLOSE) {
				jsartistic = false;
			}
		}
		bored.uncover(x, y);
	}

	public static void setaiboard(Board bored, Random rand) {
		for (int i = 0; i < 5; i++) {
			int x = rand.nextInt(bored.getRows());
			int y = rand.nextInt(bored.getCols());
			if (bored.getBoard()[x][y].getState() == CellState.EMPTYCLOSE) {
				bored.getBoard()[x][y].setState(CellState.SHIPSAFE);
			} else {
				i--;
			}
		}
	}

	/**
	 * Robust method for getting String input, "h" or "v"
	 * 
	 * @param input
	 *            user's input
	 * @param prompt
	 *            String to output in the case of invalid input
	 * @return String input if valid
	 */
	public static String getString(Scanner input, String prompt) {
		boolean valid = false;
		String x = "hello there";
		while (!valid) {
			System.out.println(prompt);
			if (input.hasNextLine()) {
				x = input.nextLine();
				valid = true;
			} else {
				input.nextLine();
				System.out.println("Not a valid string. Try again.");
			}
		}
		return x;

	}

	/**
	 * Robust method for getting Int input
	 * 
	 * @param input
	 *            user's input
	 * @param prompt
	 *            String to output in the case of invalid input
	 * @return int input if valid
	 */
	public static int getInt(Scanner input, String prompt) {
		boolean valid = false;
		int x = 66;
		while (!valid) {
			System.out.println(prompt);
			if (input.hasNextInt()) {
				x = input.nextInt();
				if (x >= 0 && x < 10) {
					valid = true;
				} else {
					input.nextLine();
					System.out.println("Not a valid integer. Try again.");
				}
			} else {
				input.nextLine();
				System.out.println("Not a valid integer. Try again.");
			}
		}
		return x;
	}
}
