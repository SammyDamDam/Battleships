package yao.samantha;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;


public class Driver {
	
	Map<String,int[]> coordinates = new Hashmap<String, int[]>();

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		Board player = new Board(10,10);
		
		player.displayBoard();
		
		System.out.println("Time to place your monkeys :D");
		System.out.println("Enter the x and y coordinates");
		System.out.println("e.g. for A1, input \"0,0\"");
		System.out.println("Where do you want your Kenny?(size:5)");
		String input = in.nextLine();
		
		
	}

}
